/**
 * Dempster-Shafer Model for Evidence-Theory
 * Abhishek Mukherji
 *  DS Model, test file.
 */

#include "dempstershafer.hpp"
#include <iostream>
#include <cstdlib>
#include <assert.h>
#include <stdio.h>
#include <cmath>

using namespace std;

typedef struct {
	string name;
	char sex;
	string haircolor;
	double height;
} Suspect;

string hypothesis_to_string_function(void* hypothesis) {
	Suspect *sus = (Suspect*) hypothesis;
	return sus->name;
}

void compress_string(char*  in_str, char* out_str, int &out_idx){
	//char* out_str = new char[10];
	char prev_char = 'S';
	int ctr=1;
	int in_idx = 0;
	//int out_idx = 0;
	cout << "reached checkpt 1" << endl;
	while(in_str[in_idx] != '\0'){
		cout << "reached checkpt 2 " << endl;
		if (in_str[in_idx]== prev_char){ // if current == previous then
						// keep incrementing the counter.
			cout << "reached checkpt 3 " << in_str[in_idx] << endl;
			ctr++;
		} else { // if curr !=prev, then
			if(ctr > 1){//output the number of repeats and reset counter.
				out_str[out_idx] = (char)(((int)'0')+ctr);
				out_idx++;

				cout << "reached checkpt 4 " << prev_char << (char)(((int)'0')+ctr) << endl;
				ctr = 1;
				cout << "ctr reset.\n";
			}
			//else { // output the new character.
				cout << "reached checkpt 5 " << in_str[in_idx] << endl;
				out_str[out_idx] = in_str[in_idx];
				out_idx++;
				//}

			// copy new character to previous.
			cout << "reached checkpt 6: old prev_char: " << prev_char << endl;
			prev_char = in_str[in_idx];
		}
		in_idx++;
	}
	if (ctr>1){//border case where the last element is also part of repeated values.
		out_str[out_idx] = (char)(((int)'0')+ctr);
		out_idx++;
	}


//return out_str;

}

int main(int argc, char** argv) {

	char* in_str = "AAACCCBDDD";
	char* out_str = new char[10];
	int out_size = 0;
	compress_string(in_str, out_str, out_size);


	for (int i=0;i<out_size; i++)
			cout << out_str[i];
		cout << endl;
	//cout<< out_str << endl;

	// create suspects
	Suspect karl;
	karl.name = "Karl"; karl.sex = 'm'; karl.haircolor = "black"; karl.height = 1.79;
	Suspect eveline;
	eveline.name = "Eveline"; eveline.sex = 'f'; eveline.haircolor = "brown"; eveline.height = 1.55;
	Suspect albert;
	albert.name = "Albert"; albert.sex = 'm'; albert.haircolor = "gray"; albert.height = 1.72;
	Suspect helga;
	helga.name = "Helga"; helga.sex = 'f'; helga.haircolor = "blond"; helga.height = 1.65;
	Suspect johannes;
	johannes.name = "Johannes"; johannes.sex = 'm'; johannes.haircolor = "gray"; johannes.height = 1.76;
	Suspect peter;
	peter.name = "Peter"; peter.sex = 'm'; peter.haircolor = "black"; peter.height = 1.80;
	Suspect frank;
	frank.name = "Frank"; frank.sex = 'm'; frank.haircolor = "black"; frank.height = 1.81;
	Suspect monika;
	monika.name = "Monika"; monika.sex = 'f'; monika.haircolor = "black"; monika.height = 1.64;

	// create Dempster-Shafer Universe
	DempsterShaferUniverse universe;
	universe.add_hypotheseses(&karl, &eveline, &albert, &helga, &johannes, &peter, &frank, &monika, NULL);

	// create evidences
	Evidence witness1 = universe.add_evidence();
	witness1.add_focal_set(0.8, &peter, &frank, &monika, &eveline, NULL); // dark hair
	witness1.add_omega_set();

	Evidence witness2 = universe.add_evidence();
	witness2.add_focal_set(0.4, &peter, &frank, NULL); // 1.80m-1.90m OR 1.70m-1.79m
	witness2.add_focal_set(0.4, &karl, &albert, &johannes, NULL); // 1.80m-1.90m OR 1.70m-1.79m
	witness2.add_omega_set();

	// combine evidences
	Evidence combined_evidences = witness1 & witness2;

	// test
	
	// basic belief function
	assert( abs(witness1.belief(&peter, &frank, &monika, &eveline, NULL)-0.8) < 0.001 );
	assert( abs(witness2.belief(&peter, &frank, NULL)-0.4) < 0.001 );
	
	// conflict should be 0.32
	assert( abs(witness1.conflict(witness2)-0.32) < 0.001 );

	// plausability and combination
	assert( abs(combined_evidences.plausability(&peter, NULL)-0.6/(1-0.32)) < 0.001 );

	cout << "Success!" << endl;
}
