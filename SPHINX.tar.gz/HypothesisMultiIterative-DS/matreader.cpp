/**
 * Dempster-Shafer Model for Evidence-Theory
 * Abhishek Mukherji
 * > mat reader, implementation
 */

#include "matreader.hpp"

using namespace std;

MATReader::MATReader(string filename) {
	 mat_t *matfp;
	 matvar_t *matvar;


	    matfp = Mat_Open(filename.c_str(),MAT_ACC_RDONLY);
	    if ( NULL == matfp ) {
	        fprintf(stderr,"Error opening MAT file \"%s\"!\n",filename.c_str());
	        //return EXIT_FAILURE;
	    }

	    //Create the columns
	    	    vector<int> *dummy;
	    	    for (int i = 0; i < headers.size(); i++) {
	    	    dummy = new vector<int>();

	    	    columns.push_back(*dummy);
	    	        		}


    	//Fill the columns
    	int counter;

	    while ( (matvar = Mat_VarReadNextInfo(matfp)) != NULL ) {
	            printf("%s\n",matvar->name);
	            Mat_VarFree(matvar);
	            matvar = NULL;
	    }

	       /* 		while(matFile.good()) {
	        			getline(matFile, line);
	        			if (line.length() == 0)
	        				break;
	        			start = 0;
	        			counter = 0;
	        			for (int i = 0; i < line.length(); i++) {
	        				if (line[i] == ';') {
	        					columns.at(counter).push_back(atoi(line.substr(start,i-start).c_str()));
	        					counter++;
	        					start = i+1;
	        				}
	        			}
	        			columns.at(counter).push_back(atoi(line.substr(start, line.length()-1-start).c_str()));
	        			if (counter+1 != headers.size()) {
	        				throw 2;
	        			}
	        		}
	        	} else {
	        		throw 3;
	        	}

	        }*/


	    Mat_Close(matfp);
	    //return EXIT_SUCCESS;

	/*ifstream matFile(filename.c_str());
	string line, header;
	if (matFile.is_open()) {
		//Get the first line of the file (header)
		getline(matFile, header);
		//Check the length of the header
		if (header.length() == 0) {
			throw 1;
		}
		//Extract the header fields
		int start = 0;
		for (int i = 0; i < header.length(); i++) {
			if (header[i] == ';') {
				headers.push_back(header.substr(start, i-start));
				start = i+1;
			}
		}
		headers.push_back(header.substr(start, header.length()-1-start));

		//Create the columns
		vector<int> *dummy;
		for (int i = 0; i < headers.size(); i++) {
			dummy = new vector<int>();
			columns.push_back(*dummy);
		}

		//Fill the columns
		int counter;
		while(matFile.good()) {
			getline(matFile, line);
			if (line.length() == 0)
				break;
			start = 0;
			counter = 0;
			for (int i = 0; i < line.length(); i++) {
				if (line[i] == ';') {
					columns.at(counter).push_back(atoi(line.substr(start,i-start).c_str()));
					counter++;
					start = i+1;
				}
			}
			columns.at(counter).push_back(atoi(line.substr(start, line.length()-1-start).c_str()));
			if (counter+1 != headers.size()) {
				throw 2;
			}
		}
	} else {
		throw 3;
	}
	matFile.close();*/
}

int MATReader::number_of_columns() {
	return headers.size();
}

int MATReader::number_of_rows() {
	return columns.at(0).size();
}

string MATReader::header(int column) {
	return headers.at(column);
}

int MATReader::value(int row, int column) {
	return columns.at(column).at(row);
}

int MATReader::value(int row, string column) {
	int index;
	if ((index = header_index(column)) != -1)
		return value(row, index);
	else
		throw 1;
}

vector<int> MATReader::column(int column) {
	return columns.at(column);
}

vector<int> MATReader::column(string column) {
	int index;
	if ((index = header_index(column)) != -1)
		return this->column(index);
	else
		throw 1;
}

vector<int> MATReader::row(int row) {
	vector<int> rowvec;
	for (int i = 0; i < headers.size(); i++) {
		rowvec.push_back(columns.at(i).at(row));
	}
	return rowvec;
}

int MATReader::header_index(string name) {
	for (int i = 0; i < headers.size(); i++) {
		if (headers.at(i).compare(name) == 0)
			return i;
	}
	return -1;
}
